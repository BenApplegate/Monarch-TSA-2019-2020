﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class catchtimer : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

        for (int i = 0; i < 20; i++)
        {
            catcher();
        }

    }

    // Update is called once per frame
    void Update()
    {
        

    }

    IEnumerator catcher()
    {
        transform.Translate(Vector3.down);
        yield return new WaitForSeconds(1);
        transform.Translate(Vector3.up);
    }
}
