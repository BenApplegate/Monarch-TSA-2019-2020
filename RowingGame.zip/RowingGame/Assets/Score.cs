﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Score : MonoBehaviour
{ 

    public coxswain chec;
    public getMedal gld;
    public getMedal slv;
    public getMedal brz;

    bool score = false;
    int numscore = 0;
    float ctime = 0f;
    float stime = 30f;

    public Text stext;

    void start()
    {
        ctime = stime;
    }

    // Update is called once per frame
    void Update()
    {
        ctime -= 1 * Time.deltaTime;

        // call and display medal at end of the game
        // almost works, just not when it hits zero
        if (ctime <= 0)
        {
            medal(numscore);
        }

        // calulate score, works meh
        if (Input.anyKey)
        {
            score = chec.getScore();
            if (score == true)
                numscore += 1;
            // should have no negative socres
            if (numscore < 0)
                numscore = 0;

            // display the score
            stext.text = "Score: " + numscore;
        }
        
    }

    // display the medals at the end of the game
    public void medal(int scr)
    {
        // the ai scores
        int scr1 = 70;
        int scr2 = 60;
        int scr3 = 50;

        if (scr > scr1 && ctime <= 0)
        {
            // diplay gold
            gld.display();
        }
        else if (scr > scr2 && ctime <= 0)
        {
            // display silver
            slv.display();
        }
        else if (scr > scr3 && ctime <= 0)
        {
            //display bronze
            brz.display();
        }
        else
        {
            // display lose
        }
    }

    
}
