﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class getMedal : MonoBehaviour
{
    public Image img;
   

    // Start is called before the first frame update
    void Start()
    {
        img.enabled = false;

    }

    // Update is called once per frame
    public void display()
    {
        img.enabled = true;
    }
}
