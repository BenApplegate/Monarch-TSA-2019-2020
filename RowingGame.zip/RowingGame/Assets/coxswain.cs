﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// coxswain changes color to tell what button to press.
public class coxswain : MonoBehaviour
{

    // this is the main script for the game and controls most of the gameplay
    private int ran = 0;
    public bool check;
    public int penalty = 0;
    public int score = 0;
    public bool gets = false;
    Camera MainCamera;
    Renderer m_Renderer;

    void Start()
    {
        // sets it to red to start, may go change to random
        gameObject.GetComponent<Renderer>().material.color = Color.red;

        //This gets the Main Camera from the Scene
        MainCamera = Camera.main;
        //This enables Main Camera
        MainCamera.enabled = true;

        // for checking if thing on screen, copied from unity docs
        m_Renderer = GetComponent<Renderer>();

    }

    void Update()
    {
        
        // create random num
        int r = Random.Range(0, 3);
        ran = r;
        Debug.Log(r);

        // get the color of the boat
        Color32 oj = gameObject.GetComponent<MeshRenderer>().material.color;
        check = testMash(oj);

        // red = space
        // blue = right
        // yellow = left
        // make sure right thing was done
        // want to add so that will move the boat and penaltys for wrong button
        if (check == true)
        {
            r = changeColor();
            // make the boat move
            gameObject.transform.Translate(-4, 0, 0);

            // when animation is made call that as well

            // make the camera move when the boat moves
            MainCamera.transform.Translate(-3, 0, 0);
        }
        else
        {
            // make the camera not move
            // stop camera move
            // **** add this ****
        }
        // if the boat goes too far back
        // does not work yet
       /* if (MainCamera.transform.position.x > gameObject.transform.position.x)
        {
            MainCamera.transform.Translate(8, 0, 0);
        }*/

        // also add to score right after
        gets = testMash(oj);
        
        // end the game, incomplete
        if (transform.position.x == 100)
        {
            // need to finish
        }

           
    }

    void OnBecameInvisible()
    {
        Camera.main.transform.Translate(-14, 0, 0); 
    }

    // changes the color, uses a random num to do so
    // color refers to what button to press
    int changeColor()
    {
        TestCoroutine();
        if (ran == 0)
        {
            gameObject.GetComponent<Renderer>().material.color = Color.red;
            int a = Random.Range(0, 3);
            return a;
        }
        else if (ran == 1)
        {
            gameObject.GetComponent<Renderer>().material.color = Color.blue;
            int a = Random.Range(0, 3);
            return a;
        }
        else if (ran == 2)
        {
            gameObject.GetComponent<Renderer>().material.color = Color.yellow;
            int a = Random.Range(0, 3);
            return a;
        }
        else
        {
            int a = 0;
            return a;
        }

    }

    // supposed to make code wait...
    IEnumerator TestCoroutine()
    {
            yield return new WaitForSeconds(2);
    }

    // check to see if the boat is ready to change color
    // need to add so that it will move
    bool testMash(Color32 obj)
    {
        Color32 objColor = obj;
        if (Input.GetKey("space") && objColor == Color.red)
        {
            score = 1;
            check = true;
            return true;
        }
        else if (Input.GetKey(KeyCode.RightArrow) && objColor == Color.blue)
        {
            score = 1;
            check = true;
            return true;
        }
        else if (Input.GetKey(KeyCode.LeftArrow) && objColor == Color.yellow)
        {
            score = 1;
            check = true;
            return true;
        }

        else
        {
            score = 0;
            check = false;
            return false;
        }
    }

    public bool getCheck()
    {
        return check;
    }

   /* public int checkPen(Color32 obj)
    {
        Color32 objColor = obj;
        // return wrong button press
        if ((Input.GetKey(KeyCode.LeftArrow) && objColor == Color.blue) ||
                 (Input.GetKey("space") && objColor == Color.blue))
        {
            penalty = 1;
        }
        else if ((Input.GetKey(KeyCode.LeftArrow) && objColor == Color.red) ||
                 (Input.GetKey(KeyCode.RightArrow) && objColor == Color.red))
        {
            penalty = 1;
        }
        else if ((Input.GetKey("space") && objColor == Color.yellow) ||
                 (Input.GetKey(KeyCode.RightArrow) && objColor == Color.yellow))
        {
            penalty = 1;
        }
        else
            penalty = 0;
        return penalty;
    }*/

    public bool getScore()
    {
        return gets;
    }
}

